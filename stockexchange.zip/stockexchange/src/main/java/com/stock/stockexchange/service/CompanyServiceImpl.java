package com.stock.stockexchange.service;

import java.sql.SQLException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.stock.stockexchange.dao.CompanyDao;
import com.stock.stockexchange.model.Company;
import org.springframework.transaction.annotation.Transactional;
@Component

public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;
	
	@Transactional
	public Company insertCompany(Company company) throws SQLException {
	   Company insertedCompany= companyDao.save(company);
		return insertedCompany;
	}
	
	

	@Override
	public List<Company> getCompanyList() throws SQLException, ClassNotFoundException {
		return companyDao.findAll();
	}
	
	

}

