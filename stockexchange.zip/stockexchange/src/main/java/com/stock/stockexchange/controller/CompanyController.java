package com.stock.stockexchange.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.dao.CompanyDao;
import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.IpoPlanned;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class CompanyController {

	@Autowired
	CompanyDao repository;

	@GetMapping("/Company/{id}")
	public List<IpoPlanned> getIPO(@PathVariable("id") int id) {
		System.out.println("get IPO  with company code = " + id + "...");

		List<IpoPlanned> ipoData = repository.findByCompanyId(id);

		return ipoData;
	}
	
	@GetMapping("/Sector/{id}")
	public List<Company> getCompany(@PathVariable("id") int id) {
		System.out.println("get Company List  with sector id = " + id + "...");

		List<Company> companyData = repository.findBySectorId(id);

		return companyData;
	}


}
